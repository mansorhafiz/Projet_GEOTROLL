/***************************************************************************/
/*                                                                         */
/*                                 Main.c                                  */
/*                                                                         */
/***************************************************************************/
/*                                                                         */
/* Programme principal                                                     */
/*                                                                         */
/***************************************************************************/
/* D�clarations : Pic.h                                                    */
/***************************************************************************/
/* Cr�ation     : 19.11.2015  L. Darras        Version 1.0                 */
/* V�rifi�      : 19.11.2015  L. Darras                                    */
/* Modification :                                                          */
/***************************************************************************/

#ifndef __VERSION                /* si pas inclusion pour symboles version */

#include "Define.h"
#include "Hard.h"
#include "Pic.h"

#endif  /* __VERSION */



/*-------------------------------------------------------------------------*/
/* D�finitions                                                             */
/*-------------------------------------------------------------------------*/

#define VERSION    "01"          /* num�ro de version (2 car) */

#define REVISION   "0"           /* num�ro de r�vision (1 car) */

#define CORRECT    " "           /* indice de correction (1 car) */

#define DEVICE     "PIC18USB"    /* type appareil : carte PIC18USB */

                                 /* bits caract�ristiques */
#define FEAT_CMDREAD   0x0001    /* pr�sence commande lecture */

                                 /* liste bits caract�ristiques compl�mentaires */
#define FEATURE    ( FEAT_CMDREAD )

#ifndef __VERSION                /* si pas inclusion pour symboles version */



/*-------------------------------------------------------------------------*/
/* Fonctions prototypes                                                    */
/*-------------------------------------------------------------------------*/

static void Init( void ) ;



/*-------------------------------------------------------------------------*/
/* Programme principal                                                     */
/*-------------------------------------------------------------------------*/

void main(void)
{
   DWORD dwBaudrate ;
   BOOL bRtsCts ;
   BYTE byRecSize ;
   BYTE bySendSize ;
   BYTE abyBuffer [100] ;
   s_Frame SendFrame ;

   Init() ;                      /* init oscillateur */
   int_Init() ;                  /* init interruptions */
   ti_Init() ;                   /* init timer */
   runled_Init() ;               /* init led run */

//   frmcom_Init() ;               /* init communication avec Uart PC */

   for ( ; ; )
   {
      for ( ; ; )
      {
         runled_TaskCyc() ;      /* traitement clignotement led run */
//         com_ProcessCmd() ;      /* traitement commandes */

                                 /* si besoin mode transparent */
//         if ( cmicro_IsNeedTrans( &dwBaudrate, &bRtsCts, TRUE ) )
//         {
//            break ;
//         }
      }

                                 /* attente fin �mission r�ponse */
//      while ( !ua2_IsSendEmpty() ) ;

//      frmcom_UnInit( ) ;         /* deinit framecom avec Uart PC */

//      ua1_Open( dwBaudrate ) ;   /* ouverture Uart VNC */

                                 /* reouverture Uart PC */
//      ua2_Open( dwBaudrate, bRtsCts ) ;

                                 /* s�quence reset uniquement si ligne PIC_VNC_RESET */
                                 /* a pr�alablement �t� mise � 0 */
                                 /* reboote VNC en run si ligne PIC_VNC_PROG � 1, */
                                 /* en bootloader si ligne PIC_VNC_PROG � 0 */
//      tp_Delay( 100 ) ;
//      O_PIC_VNC_RESET = 1 ;

//      for ( ; ; )
//      {
                                 /* mode transparent Uart 2 vers Uart 1 */
//         byRecSize = ua2_GetReceiveSize() ;
//         if ( byRecSize != 0 )
//         {
//            bySendSize = ua1_GetSendSize() ;
//            if ( byRecSize > bySendSize )
//               byRecSize = bySendSize ;
//            if ( byRecSize != 0 )
//            {
//               if ( byRecSize > sizeof(abyBuffer) )
//                  byRecSize = sizeof(abyBuffer) ;
//               ua2_Receive( abyBuffer, byRecSize ) ;
//               ua1_Send( (BYTE C*)abyBuffer, byRecSize ) ;
//            }
//         }
                                 /* mode transparent Uart 1 vers Uart 2 */
//         byRecSize = ua1_GetReceiveSize() ;
//         if ( byRecSize != 0 )
//         {
//            bySendSize = ua2_GetSendSize() ;
//            if ( byRecSize > bySendSize )
//               byRecSize = bySendSize ;
//            if ( byRecSize != 0 )
//            {
//               if ( byRecSize > sizeof(abyBuffer) )
//                  byRecSize = sizeof(abyBuffer) ;
//               ua1_Receive( abyBuffer, byRecSize ) ;
//               ua2_Send( (BYTE C*)abyBuffer, byRecSize ) ;
//            }
//         }
                                 /* si r�ception break de Uart PC */
//         if ( ua2_IsBreak( TRUE ) )
//            break ;
//      }

//      ua2_Close() ;              /* fermeture Uart PC */
//      ua1_Close() ;              /* fermeture Uart VNC */

//      frmcom_Init() ;            /* re-init communication avec Uart PC */
   }

}



/*=========================================================================*/

/*-------------------------------------------------------------------------*/
/* Initialisation principale                                               */
/*-------------------------------------------------------------------------*/

static void Init( void )
{
                              /* configuration oscillateur */
   OSCCONbits.IDLEN = 0 ;
                              /* s�lection oscillateur primaire par SCS1:0 */
   OSCCONbits.SCS1 = 0 ;
   OSCCONbits.SCS0 = 0 ;

//   OSCTUNEbits.PLLEN = 1 ;    /* activation PLL */

   ADCON1 = 0x0F ;            /* PCFG[3:0] � 1 pour consid�rer toutes entr�es num�riques */

}

#endif
